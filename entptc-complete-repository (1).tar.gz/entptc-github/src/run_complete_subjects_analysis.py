#!/usr/bin/env python3.11
"""
EntPTC Analysis - Complete Subjects Only
=========================================

Process only the 40 complete subjects through full EntPTC pipeline.

Author: EntPTC Research Team
Date: December 2024
"""

import sys
sys.path.append('/home/ubuntu')

from entptc_pytorch_simulation import EntPTCPipeline
import pandas as pd
import numpy as np
from pathlib import Path
from tqdm import tqdm
import torch

def main():
    print("=" * 80)
    print("EntPTC Analysis - Complete Subjects Only")
    print("=" * 80)
    
    # Load complete subjects list
    subjects_df = pd.read_csv('/home/ubuntu/entptc_results/complete_subjects.csv')
    
    print(f"\nComplete subjects: {len(subjects_df)}")
    print(f"Total EDF files: {len(subjects_df) * 4}")
    print()
    
    # Initialize pipeline
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    pipeline = EntPTCPipeline(device=device)
    
    print(f"Device: {device}")
    print("\nProcessing through complete EntPTC pipeline:")
    print("  - Quaternionic filtering (Stage 1)")
    print("  - Real projection (Stage 2)")
    print("  - Perron-Frobenius collapse (Stage 3)")
    print("  - Entropy field on T³")
    print("  - Geodesic computation")
    print("  - Absurdity Gap (POST-OPERATOR)")
    print("  - THz inference (structural invariants, NO conversion)")
    print()
    
    # Process all files
    results_list = []
    failed_files = []
    
    for idx, row in tqdm(subjects_df.iterrows(), total=len(subjects_df), desc="Processing subjects"):
        subject_id = row['subject_id']
        
        # Process all 4 conditions
        for condition in ['EO_pre', 'EC_pre', 'EO_post', 'EC_post']:
            edf_path = row[f'{condition}_path']
            
            try:
                result = pipeline.process_edf_file(edf_path)
                
                if result is not None:
                    result['subject_id'] = subject_id
                    result['condition'] = condition
                    result['task'] = 'EyesOpen' if 'EO' in condition else 'EyesClosed'
                    result['acq'] = 'pre' if 'pre' in condition else 'post'
                    results_list.append(result)
                else:
                    failed_files.append((subject_id, condition, "Returned None"))
            except Exception as e:
                failed_files.append((subject_id, condition, str(e)))
                print(f"\nError: {subject_id} {condition}: {e}")
    
    print(f"\n\nProcessing complete!")
    print(f"  Successful: {len(results_list)}")
    print(f"  Failed: {len(failed_files)}")
    
    # Save results
    if results_list:
        print("\nSaving results to CSV...")
        df = pd.DataFrame(results_list)
        
        # Reorder columns
        cols = ['subject_id', 'condition', 'task', 'acq', 'lambda_max', 'lambda_2',
                'spectral_gap', 'entropy', 'absurdity_gap', 'thz_ratio',
                'thz_normalized_gap', 'thz_decay_exponent', 'thz_inferred', 'thz_confidence']
        df = df[cols]
        
        output_path = Path('/home/ubuntu/entptc_results/entptc_complete_subjects_results.csv')
        df.to_csv(output_path, index=False)
        print(f"Results saved to: {output_path}")
        
        # Generate summary statistics
        print("\nGenerating summary statistics...")
        summary = generate_summary_statistics(df)
        summary_path = Path('/home/ubuntu/entptc_results/entptc_complete_subjects_summary.csv')
        summary.to_csv(summary_path)
        print(f"Summary saved to: {summary_path}")
        
        # Print key findings
        print("\n" + "=" * 80)
        print("KEY FINDINGS")
        print("=" * 80)
        print(f"\nOverall Statistics (N={len(df)} recordings, {len(subjects_df)} subjects):")
        print(f"  λ_max:         {df['lambda_max'].mean():.4f} ± {df['lambda_max'].std():.4f}")
        print(f"  Spectral gap:  {df['spectral_gap'].mean():.4f} ± {df['spectral_gap'].std():.4f}")
        print(f"  Entropy:       {df['entropy'].mean():.4f} ± {df['entropy'].std():.4f}")
        print(f"  Absurdity Gap: {df['absurdity_gap'].mean():.4f} ± {df['absurdity_gap'].std():.4f}")
        print(f"  THz inferred:  {df['thz_inferred'].sum()}/{len(df)} ({100*df['thz_inferred'].mean():.1f}%)")
        
        print("\nBy Task:")
        for task in df['task'].unique():
            task_df = df[df['task'] == task]
            print(f"\n  {task} (N={len(task_df)}):")
            print(f"    Spectral gap:  {task_df['spectral_gap'].mean():.4f} ± {task_df['spectral_gap'].std():.4f}")
            print(f"    Absurdity Gap: {task_df['absurdity_gap'].mean():.4f} ± {task_df['absurdity_gap'].std():.4f}")
        
        print("\nBy Acquisition:")
        for acq in df['acq'].unique():
            acq_df = df[df['acq'] == acq]
            print(f"\n  {acq} (N={len(acq_df)}):")
            print(f"    Spectral gap:  {acq_df['spectral_gap'].mean():.4f} ± {acq_df['spectral_gap'].std():.4f}")
            print(f"    Absurdity Gap: {acq_df['absurdity_gap'].mean():.4f} ± {acq_df['absurdity_gap'].std():.4f}")
    
    # Save failed files log
    if failed_files:
        failed_df = pd.DataFrame(failed_files, 
                                columns=['subject_id', 'condition', 'error'])
        failed_path = Path('/home/ubuntu/entptc_results/failed_files_complete.csv')
        failed_df.to_csv(failed_path, index=False)
        print(f"\nFailed files log saved to: {failed_path}")
    
    print("\n" + "=" * 80)
    print("Analysis complete!")
    print("=" * 80)

def generate_summary_statistics(df):
    """Generate summary statistics by condition."""
    summary_stats = []
    
    # Overall
    summary_stats.append({
        'condition': 'All',
        'n': len(df),
        'lambda_max_mean': df['lambda_max'].mean(),
        'lambda_max_std': df['lambda_max'].std(),
        'spectral_gap_mean': df['spectral_gap'].mean(),
        'spectral_gap_std': df['spectral_gap'].std(),
        'entropy_mean': df['entropy'].mean(),
        'entropy_std': df['entropy'].std(),
        'absurdity_gap_mean': df['absurdity_gap'].mean(),
        'absurdity_gap_std': df['absurdity_gap'].std(),
        'thz_inferred_pct': 100 * df['thz_inferred'].mean()
    })
    
    # By task
    for task in df['task'].unique():
        task_df = df[df['task'] == task]
        summary_stats.append({
            'condition': f'Task: {task}',
            'n': len(task_df),
            'lambda_max_mean': task_df['lambda_max'].mean(),
            'lambda_max_std': task_df['lambda_max'].std(),
            'spectral_gap_mean': task_df['spectral_gap'].mean(),
            'spectral_gap_std': task_df['spectral_gap'].std(),
            'entropy_mean': task_df['entropy'].mean(),
            'entropy_std': task_df['entropy'].std(),
            'absurdity_gap_mean': task_df['absurdity_gap'].mean(),
            'absurdity_gap_std': task_df['absurdity_gap'].std(),
            'thz_inferred_pct': 100 * task_df['thz_inferred'].mean()
        })
    
    # By acquisition
    for acq in df['acq'].unique():
        acq_df = df[df['acq'] == acq]
        summary_stats.append({
            'condition': f'Acquisition: {acq}',
            'n': len(acq_df),
            'lambda_max_mean': acq_df['lambda_max'].mean(),
            'lambda_max_std': acq_df['lambda_max'].std(),
            'spectral_gap_mean': acq_df['spectral_gap'].mean(),
            'spectral_gap_std': acq_df['spectral_gap'].std(),
            'entropy_mean': acq_df['entropy'].mean(),
            'entropy_std': acq_df['entropy'].std(),
            'absurdity_gap_mean': acq_df['absurdity_gap'].mean(),
            'absurdity_gap_std': acq_df['absurdity_gap'].std(),
            'thz_inferred_pct': 100 * acq_df['thz_inferred'].mean()
        })
    
    return pd.DataFrame(summary_stats)

if __name__ == "__main__":
    main()
