# Dataset Download Instructions

## OpenNeuro ds005385

**Full Citation:**
Getzmann, S., Reiser, J. E., Karthaus, M., Rudack, C., & Wascher, E. (2024). 
*Resting-state EEG in younger and older adults with and without hearing loss* (Version 1.0.0) [Data set]. 
OpenNeuro. https://doi.org/10.18112/openneuro.ds005385.v1.0.0

## Download Methods

### Method 1: AWS CLI (Recommended)

```bash
# Install AWS CLI
pip install awscli

# Download dataset
aws s3 sync --no-sign-request \
  s3://openneuro.org/ds005385 \
  ./ds005385_full
```

### Method 2: DataLad

```bash
# Install DataLad
pip install datalad

# Clone dataset
datalad clone https://github.com/OpenNeuroDatasets/ds005385.git

# Download all files
cd ds005385
datalad get .
```

### Method 3: Web Browser

Visit: https://openneuro.org/datasets/ds005385/versions/1.0.0

Click "Download" and select your preferred method.

## Dataset Size

- **Total**: ~74 GB
- **Complete subjects needed**: ~2-3 GB (40 subjects × 4 files)

## File Structure

```
ds005385/
├── sub-001/
│   ├── ses-1/
│   │   └── eeg/
│   │       ├── sub-001_ses-1_task-EyesOpen_acq-pre_eeg.edf
│   │       ├── sub-001_ses-1_task-EyesOpen_acq-post_eeg.edf
│   │       ├── sub-001_ses-1_task-EyesClosed_acq-pre_eeg.edf
│   │       └── sub-001_ses-1_task-EyesClosed_acq-post_eeg.edf
│   └── ses-2/
│       └── eeg/
│           └── (similar structure)
├── sub-002/
└── ...
```

## Required Files

For EntPTC analysis, you need subjects with **complete blocks**:

- `task-EyesOpen_acq-pre_eeg.edf`
- `task-EyesOpen_acq-post_eeg.edf`
- `task-EyesClosed_acq-pre_eeg.edf`
- `task-EyesClosed_acq-post_eeg.edf`

Use `find_complete_subjects.py` to identify which subjects have all required files.

## Partial Download

If disk space is limited, you can download only complete subjects:

```bash
# After identifying complete subjects
# Download specific subjects only
for sub in sub-001 sub-030 sub-047; do
  aws s3 sync --no-sign-request \
    s3://openneuro.org/ds005385/$sub \
    ./ds005385_full/$sub
done
```

## Verification

After download, verify file integrity:

```bash
python src/find_complete_subjects.py
```

Expected output: 40 complete subjects (160 EDF files)
