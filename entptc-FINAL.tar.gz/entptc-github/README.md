# EntPTC: Entropic Toroidal Progenitor Theory of Consciousness

**A deterministic operator-based model of experience validated through large-scale resting-state EEG analysis**

## Overview

EntPTC (Entropic Toroidal Progenitor Theory of Consciousness) is a mathematical framework that models conscious experience as an entropy-minimizing field on a toroidal manifold, resolved through quaternionic filtering and Perron-Frobenius operator collapse.

## Key Features

- **Quaternionic Hilbert Space Filtering**: Context-dependent phase relationships preserved through non-commutative algebra
- **Two-Stage Reduction**: Quaternionic → Real projection followed by Perron-Frobenius collapse
- **16×16 Progenitor Matrix**: Dimensionality reduction from 64-channel EEG coherence
- **Entropy Field on T³**: Toroidal manifold representation of conscious states
- **Geodesic Computation**: Euler-Lagrange optimization for entropy-minimizing trajectories
- **Absurdity Gap**: Post-operator validation metric (deviation from optimal geodesic)
- **THz Inference**: Structural invariant matching (NO frequency conversion)

## Scientific Status

**Validation Dataset**: 40 complete subjects from OpenNeuro ds005385 (Getzmann et al., 2024)
- 160 EDF files total (EO/EC × pre/post per subject)
- 65 channels, 1000Hz sampling rate
- Resting-state recordings

**Assessment**: Strong methods validation paper (theory + mechanism)

**Framing**: This analysis validates the structural convergence of the EntPTC operator. Population-level generalization is reserved for future work.

## Repository Structure

```
entptc-github/
├── README.md                 # This file
├── LICENSE                   # License information
├── requirements.txt          # Python dependencies
├── src/                      # Source code
│   ├── entptc_pytorch_simulation.py      # Core EntPTC implementation
│   ├── run_complete_subjects_analysis.py # Analysis script
│   ├── find_complete_subjects.py         # Subject selection tool
│   └── generate_visualizations.py        # Plotting and figures
├── paper/                    # Academic paper
│   ├── paper1_fixed(1).tex   # LaTeX source
│   ├── entptcref122(4).bib   # Bibliography
│   └── paper1_fixed(1).pdf   # Compiled PDF
├── results/                  # Analysis results
│   ├── complete_subjects.csv                    # Subject list
│   ├── entptc_complete_subjects_results.csv     # Full results
│   └── entptc_complete_subjects_summary.csv     # Summary statistics
├── figures/                  # Visualizations
│   └── (generated figures)
├── docs/                     # Documentation
│   ├── METHODS.md           # Detailed methodology
│   ├── DATA_REQUIREMENTS.md # EDF file selection criteria
│   └── THEORY.md            # Theoretical framework
└── data/                     # Data access instructions
    └── DOWNLOAD.md          # How to get OpenNeuro dataset
```

## Installation

### Requirements

- Python 3.11+
- PyTorch
- NumPy, Pandas, Matplotlib
- SciPy
- pyEDFlib
- tqdm

### Setup

```bash
# Clone repository
git clone https://github.com/your-username/entptc.git
cd entptc

# Install dependencies
pip install -r requirements.txt

# Download dataset (see data/DOWNLOAD.md)
```

## Usage

### 1. Find Complete Subjects

```bash
python src/find_complete_subjects.py
```

This identifies subjects with complete EO/EC × pre/post blocks.

### 2. Run EntPTC Analysis

```bash
python src/run_complete_subjects_analysis.py
```

Processes all complete subjects through the full EntPTC pipeline.

### 3. Generate Visualizations

```bash
python src/generate_visualizations.py
```

Creates publication-quality figures.

## Core Methodology

### Stage 1: Quaternionic Filtering

```python
# Non-commutative phase smoothing
q = a + bi + cj + dk
ψ' = q ψ q*
```

### Stage 2: Real Projection

```python
# Magnitude projection to real space
C^(r) = |C^(q)|
```

### Stage 3: Perron-Frobenius Collapse

```python
# Multiplicity resolution
lim_{n→∞} (C^(r))^n / λ_max^n = v_1
```

### Absurdity Gap Computation (Post-Operator Only)

```python
# Geodesic deviation
Δ = mean(||γ_opt(t) - γ_obs(t)||_T³)
```

### THz Inference (Structural Invariants)

```python
# NO frequency conversion
# Dimensionless ratios only
R_12 = λ_1 / λ_2
R_23 = λ_2 / λ_3
α = -d(log λ_n)/dn
```

## Key Results

(Results will be populated after analysis completes)

- **Spectral Gap**: Mean ± SD
- **Entropy**: Mean ± SD
- **Absurdity Gap**: Mean ± SD
- **THz Inference**: Percentage of recordings showing structural correspondence

## Citation

```bibtex
@article{entptc2024,
  title={EntPTC: Entropic Toroidal Progenitor Theory of Consciousness},
  author={[Authors]},
  journal={[Journal]},
  year={2024},
  note={Preprint}
}
```

## Data Source

Getzmann, S., Reiser, J. E., Karthaus, M., Rudack, C., & Wascher, E. (2024). 
*Resting-state EEG in younger and older adults with and without hearing loss* (Version 1.0.0) [Data set]. 
OpenNeuro. https://doi.org/10.18112/openneuro.ds005385.v1.0.0

## License

[Specify license - e.g., MIT, GPL, etc.]

## Contact

[Contact information]

## Acknowledgments

- OpenNeuro for dataset hosting
- Getzmann et al. for data collection
- [Other acknowledgments]

---

**Important Notes:**

1. **Quaternions vs Perron-Frobenius**: Quaternionic structure is used exclusively for local phase stabilization. Multiplicity resolution is performed only after projection to a real, non-negative coherence matrix, where Perron-Frobenius guarantees a unique dominant mode.

2. **THz Inference**: The THz control layer is inferred through dimensionless structural invariants, not through direct frequency conversion. There is no unit conversion from EEG (Hz) to THz.

3. **Subject Selection**: Only subjects with complete EO/EC × pre/post resting-state blocks are included to ensure within-subject structural consistency.

4. **Falsifiability**: If operator-stabilized eigenstructures do not correspond to reduced Absurdity Gap values, the inferred THz control hypothesis is falsified.
