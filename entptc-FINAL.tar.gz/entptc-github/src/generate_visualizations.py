#!/usr/bin/env python3.11
"""
Visualization Generation Script for EntPTC Analysis
====================================================

This script generates all required visualizations for the EntPTC paper and
Simulation/Data/Analysis PDF:

1. Eigenvalue spectra plots
2. Coherence matrix heatmaps
3. Entropy field on toroidal manifold
4. Geodesic vs observed trajectories
5. Absurdity Gap across conditions
6. THz structural invariant plots

All figures are saved to /home/ubuntu/entptc_results/figures/

Author: EntPTC Research Team
Date: December 2024
"""

import os
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib as mpl
from mpl_toolkits.mplot3d import Axes3D
import seaborn as sns
import warnings
warnings.filterwarnings('ignore')

# Set publication-quality defaults
plt.rcParams['figure.dpi'] = 300
plt.rcParams['savefig.dpi'] = 300
plt.rcParams['font.size'] = 10
plt.rcParams['font.family'] = 'serif'
plt.rcParams['axes.labelsize'] = 11
plt.rcParams['axes.titlesize'] = 12
plt.rcParams['xtick.labelsize'] = 9
plt.rcParams['ytick.labelsize'] = 9
plt.rcParams['legend.fontsize'] = 9

class VisualizationGenerator:
    """
    Generate all visualizations for EntPTC analysis.
    """
    
    def __init__(self, results_dir='/home/ubuntu/entptc_results'):
        self.results_dir = Path(results_dir)
        self.figures_dir = self.results_dir / 'figures'
        
        # Create subdirectories
        self.subdirs = {
            'eigenvalue_spectra': self.figures_dir / 'eigenvalue_spectra',
            'coherence_matrices': self.figures_dir / 'coherence_matrices',
            'entropy_fields': self.figures_dir / 'entropy_fields',
            'geodesic_trajectories': self.figures_dir / 'geodesic_trajectories',
            'absurdity_gap': self.figures_dir / 'absurdity_gap',
            'thz_invariants': self.figures_dir / 'thz_invariants',
            'summary': self.figures_dir / 'summary'
        }
        
        for subdir in self.subdirs.values():
            subdir.mkdir(parents=True, exist_ok=True)
        
        print(f"Visualization Generator initialized")
        print(f"Figures directory: {self.figures_dir}")
    
    def plot_eigenvalue_spectrum(self, eigenvalues, subject_id, session, task, acq):
        """
        Plot eigenvalue spectrum with spectral gap highlighted.
        """
        fig, ax = plt.subplots(figsize=(8, 5))
        
        indices = np.arange(len(eigenvalues))
        ax.plot(indices, eigenvalues, 'o-', linewidth=2, markersize=6, 
                color='#2E86AB', label='Eigenvalues')
        
        # Highlight spectral gap
        ax.axhline(y=eigenvalues[0], color='red', linestyle='--', alpha=0.5, 
                   label=f'λ_max = {eigenvalues[0]:.3f}')
        ax.axhline(y=eigenvalues[1], color='orange', linestyle='--', alpha=0.5,
                   label=f'λ_2 = {eigenvalues[1]:.3f}')
        
        # Fill spectral gap
        ax.fill_between([0, len(eigenvalues)-1], eigenvalues[0], eigenvalues[1],
                        alpha=0.2, color='red', label=f'Spectral gap = {eigenvalues[0]-eigenvalues[1]:.3f}')
        
        ax.set_xlabel('Eigenvalue Index')
        ax.set_ylabel('Eigenvalue Magnitude')
        ax.set_title(f'Eigenvalue Spectrum: {subject_id} {session} {task} {acq}')
        ax.legend()
        ax.grid(True, alpha=0.3)
        
        filename = f'eigenspectrum_{subject_id}_{session}_{task}_{acq}.png'
        filepath = self.subdirs['eigenvalue_spectra'] / filename
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def plot_coherence_matrix(self, coherence_matrix, subject_id, session, task, acq):
        """
        Plot coherence matrix as heatmap.
        """
        fig, ax = plt.subplots(figsize=(10, 8))
        
        im = ax.imshow(coherence_matrix, cmap='viridis', aspect='auto', 
                       vmin=0, vmax=1)
        
        ax.set_xlabel('Region Index')
        ax.set_ylabel('Region Index')
        ax.set_title(f'Coherence Matrix (16×16): {subject_id} {session} {task} {acq}')
        
        cbar = plt.colorbar(im, ax=ax)
        cbar.set_label('Phase Locking Value', rotation=270, labelpad=20)
        
        filename = f'coherence_{subject_id}_{session}_{task}_{acq}.png'
        filepath = self.subdirs['coherence_matrices'] / filename
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def plot_entropy_field_3d(self, eigenvalues, subject_id, session, task, acq):
        """
        Plot 3D entropy field on toroidal manifold.
        """
        fig = plt.figure(figsize=(12, 9))
        ax = fig.add_subplot(111, projection='3d')
        
        # Create grid on torus
        L = 2 * np.pi
        n_points = 30
        x = np.linspace(0, L, n_points)
        y = np.linspace(0, L, n_points)
        X, Y = np.meshgrid(x, y)
        
        # Compute entropy field
        eigenvalues_pos = np.maximum(eigenvalues, 1e-10)
        p = eigenvalues_pos / np.sum(eigenvalues_pos)
        S_base = -np.sum(p * np.log(p + 1e-10))
        
        Z = np.zeros_like(X)
        for i in range(n_points):
            for j in range(n_points):
                spatial_mod = 1.0 + 0.3 * np.sin(X[i,j]) * np.cos(Y[i,j])
                Z[i,j] = S_base * spatial_mod
        
        # Plot surface
        surf = ax.plot_surface(X, Y, Z, cmap='plasma', alpha=0.8, 
                              linewidth=0, antialiased=True)
        
        ax.set_xlabel('x₁ (toroidal coordinate)')
        ax.set_ylabel('x₂ (toroidal coordinate)')
        ax.set_zlabel('Entropy S(x)')
        ax.set_title(f'Entropy Field on T³: {subject_id} {session} {task} {acq}')
        
        fig.colorbar(surf, ax=ax, shrink=0.5, aspect=5)
        
        filename = f'entropy_field_3d_{subject_id}_{session}_{task}_{acq}.png'
        filepath = self.subdirs['entropy_fields'] / filename
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def plot_geodesic_trajectories(self, gamma_opt, gamma_obs, subject_id, session, task, acq):
        """
        Plot optimal geodesic vs observed trajectory.
        """
        fig = plt.figure(figsize=(14, 5))
        
        # 3D plot
        ax1 = fig.add_subplot(131, projection='3d')
        ax1.plot(gamma_opt[:, 0], gamma_opt[:, 1], gamma_opt[:, 2], 
                'b-', linewidth=2, label='Optimal geodesic γ_opt', alpha=0.7)
        ax1.plot(gamma_obs[:, 0], gamma_obs[:, 1], gamma_obs[:, 2],
                'r--', linewidth=2, label='Observed trajectory γ_obs', alpha=0.7)
        ax1.set_xlabel('x₁')
        ax1.set_ylabel('x₂')
        ax1.set_zlabel('x₃')
        ax1.set_title('3D Trajectories on T³')
        ax1.legend()
        
        # 2D projections
        ax2 = fig.add_subplot(132)
        ax2.plot(gamma_opt[:, 0], gamma_opt[:, 1], 'b-', linewidth=2, 
                label='γ_opt', alpha=0.7)
        ax2.plot(gamma_obs[:, 0], gamma_obs[:, 1], 'r--', linewidth=2,
                label='γ_obs', alpha=0.7)
        ax2.set_xlabel('x₁')
        ax2.set_ylabel('x₂')
        ax2.set_title('Projection: x₁-x₂ plane')
        ax2.legend()
        ax2.grid(True, alpha=0.3)
        
        # Deviation over time
        ax3 = fig.add_subplot(133)
        n_steps = min(len(gamma_opt), len(gamma_obs))
        diff = gamma_opt[:n_steps] - gamma_obs[:n_steps]
        
        # Toroidal distance
        L = 2 * np.pi
        for i in range(3):
            diff[:, i] = np.minimum(np.abs(diff[:, i]), L - np.abs(diff[:, i]))
        
        distances = np.linalg.norm(diff, axis=1)
        ax3.plot(distances, linewidth=2, color='purple')
        ax3.axhline(y=np.mean(distances), color='red', linestyle='--', 
                   label=f'Absurdity Gap = {np.mean(distances):.3f}')
        ax3.set_xlabel('Time Step')
        ax3.set_ylabel('Deviation')
        ax3.set_title('Absurdity Gap Evolution')
        ax3.legend()
        ax3.grid(True, alpha=0.3)
        
        plt.suptitle(f'{subject_id} {session} {task} {acq}', fontsize=14)
        
        filename = f'geodesic_{subject_id}_{session}_{task}_{acq}.png'
        filepath = self.subdirs['geodesic_trajectories'] / filename
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def plot_absurdity_gap_comparison(self, df):
        """
        Plot Absurdity Gap across all conditions.
        """
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # By task
        ax1 = axes[0, 0]
        tasks = df['task'].unique()
        absurdity_by_task = [df[df['task'] == task]['absurdity_gap'].values 
                             for task in tasks]
        bp1 = ax1.boxplot(absurdity_by_task, labels=tasks, patch_artist=True)
        for patch in bp1['boxes']:
            patch.set_facecolor('#2E86AB')
        ax1.set_ylabel('Absurdity Gap')
        ax1.set_title('Absurdity Gap by Task')
        ax1.grid(True, alpha=0.3, axis='y')
        
        # By acquisition
        ax2 = axes[0, 1]
        acqs = df['acq'].unique()
        absurdity_by_acq = [df[df['acq'] == acq]['absurdity_gap'].values 
                           for acq in acqs]
        bp2 = ax2.boxplot(absurdity_by_acq, labels=acqs, patch_artist=True)
        for patch in bp2['boxes']:
            patch.set_facecolor('#A23B72')
        ax2.set_ylabel('Absurdity Gap')
        ax2.set_title('Absurdity Gap by Acquisition')
        ax2.grid(True, alpha=0.3, axis='y')
        
        # By task and acquisition
        ax3 = axes[1, 0]
        conditions = []
        absurdity_by_condition = []
        for task in tasks:
            for acq in acqs:
                cond_df = df[(df['task'] == task) & (df['acq'] == acq)]
                if len(cond_df) > 0:
                    conditions.append(f'{task}\n{acq}')
                    absurdity_by_condition.append(cond_df['absurdity_gap'].values)
        
        bp3 = ax3.boxplot(absurdity_by_condition, labels=conditions, patch_artist=True)
        colors = ['#2E86AB', '#A23B72', '#F18F01', '#C73E1D']
        for patch, color in zip(bp3['boxes'], colors * (len(bp3['boxes']) // len(colors) + 1)):
            patch.set_facecolor(color)
        ax3.set_ylabel('Absurdity Gap')
        ax3.set_title('Absurdity Gap by Task × Acquisition')
        ax3.grid(True, alpha=0.3, axis='y')
        plt.setp(ax3.xaxis.get_majorticklabels(), rotation=45, ha='right')
        
        # Histogram
        ax4 = axes[1, 1]
        ax4.hist(df['absurdity_gap'], bins=30, color='#2E86AB', alpha=0.7, edgecolor='black')
        ax4.axvline(x=df['absurdity_gap'].mean(), color='red', linestyle='--', 
                   linewidth=2, label=f'Mean = {df["absurdity_gap"].mean():.3f}')
        ax4.set_xlabel('Absurdity Gap')
        ax4.set_ylabel('Frequency')
        ax4.set_title('Absurdity Gap Distribution')
        ax4.legend()
        ax4.grid(True, alpha=0.3, axis='y')
        
        plt.suptitle('Absurdity Gap Analysis Across All Conditions', fontsize=16)
        plt.tight_layout()
        
        filepath = self.subdirs['absurdity_gap'] / 'absurdity_gap_comparison.png'
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def plot_thz_structural_invariants(self, df):
        """
        Plot THz structural invariants across conditions.
        """
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))
        
        # Eigenvalue ratio
        ax1 = axes[0, 0]
        ax1.scatter(df['spectral_gap'], df['thz_ratio'], alpha=0.6, s=50, c='#2E86AB')
        ax1.set_xlabel('Spectral Gap')
        ax1.set_ylabel('λ_max / λ_2 Ratio')
        ax1.set_title('THz Structural Invariant: Eigenvalue Ratio')
        ax1.grid(True, alpha=0.3)
        
        # Normalized gap
        ax2 = axes[0, 1]
        ax2.scatter(df['entropy'], df['thz_normalized_gap'], alpha=0.6, s=50, c='#A23B72')
        ax2.set_xlabel('Entropy')
        ax2.set_ylabel('Normalized Spectral Gap')
        ax2.set_title('THz Structural Invariant: Normalized Gap')
        ax2.grid(True, alpha=0.3)
        
        # Decay exponent
        ax3 = axes[1, 0]
        ax3.hist(df['thz_decay_exponent'], bins=30, color='#F18F01', alpha=0.7, edgecolor='black')
        ax3.set_xlabel('Decay Exponent')
        ax3.set_ylabel('Frequency')
        ax3.set_title('THz Structural Invariant: Eigenvalue Decay')
        ax3.grid(True, alpha=0.3, axis='y')
        
        # Ratio vs Absurdity Gap
        ax4 = axes[1, 1]
        scatter = ax4.scatter(df['thz_ratio'], df['absurdity_gap'], 
                             c=df['entropy'], cmap='viridis', alpha=0.6, s=50)
        ax4.set_xlabel('λ_max / λ_2 Ratio')
        ax4.set_ylabel('Absurdity Gap')
        ax4.set_title('THz Ratio vs Absurdity Gap (colored by Entropy)')
        ax4.grid(True, alpha=0.3)
        cbar = plt.colorbar(scatter, ax=ax4)
        cbar.set_label('Entropy')
        
        plt.suptitle('THz Structural Invariants (NO Frequency Conversion)', fontsize=16)
        plt.tight_layout()
        
        filepath = self.subdirs['thz_invariants'] / 'thz_structural_invariants.png'
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def plot_summary_statistics(self, df):
        """
        Plot comprehensive summary statistics.
        """
        fig, axes = plt.subplots(3, 2, figsize=(14, 16))
        
        # Spectral gap distribution
        ax1 = axes[0, 0]
        ax1.hist(df['spectral_gap'], bins=30, color='#2E86AB', alpha=0.7, edgecolor='black')
        ax1.axvline(x=df['spectral_gap'].mean(), color='red', linestyle='--', linewidth=2)
        ax1.set_xlabel('Spectral Gap')
        ax1.set_ylabel('Frequency')
        ax1.set_title(f'Spectral Gap Distribution (μ={df["spectral_gap"].mean():.3f})')
        ax1.grid(True, alpha=0.3, axis='y')
        
        # Entropy distribution
        ax2 = axes[0, 1]
        ax2.hist(df['entropy'], bins=30, color='#A23B72', alpha=0.7, edgecolor='black')
        ax2.axvline(x=df['entropy'].mean(), color='red', linestyle='--', linewidth=2)
        ax2.set_xlabel('Entropy')
        ax2.set_ylabel('Frequency')
        ax2.set_title(f'Entropy Distribution (μ={df["entropy"].mean():.3f})')
        ax2.grid(True, alpha=0.3, axis='y')
        
        # Spectral gap vs Entropy
        ax3 = axes[1, 0]
        ax3.scatter(df['spectral_gap'], df['entropy'], alpha=0.6, s=50, c='#F18F01')
        ax3.set_xlabel('Spectral Gap')
        ax3.set_ylabel('Entropy')
        ax3.set_title('Spectral Gap vs Entropy')
        ax3.grid(True, alpha=0.3)
        
        # Regime classification
        ax4 = axes[1, 1]
        regime_counts = df['regime'].value_counts()
        ax4.bar(range(len(regime_counts)), regime_counts.values, color='#C73E1D', alpha=0.7)
        ax4.set_xticks(range(len(regime_counts)))
        ax4.set_xticklabels(regime_counts.index, rotation=45, ha='right')
        ax4.set_ylabel('Count')
        ax4.set_title('Regime Classification Distribution')
        ax4.grid(True, alpha=0.3, axis='y')
        
        # Lambda_max distribution
        ax5 = axes[2, 0]
        ax5.hist(df['lambda_max'], bins=30, color='#2E86AB', alpha=0.7, edgecolor='black')
        ax5.axvline(x=df['lambda_max'].mean(), color='red', linestyle='--', linewidth=2)
        ax5.set_xlabel('λ_max')
        ax5.set_ylabel('Frequency')
        ax5.set_title(f'λ_max Distribution (μ={df["lambda_max"].mean():.3f})')
        ax5.grid(True, alpha=0.3, axis='y')
        
        # Correlation heatmap
        ax6 = axes[2, 1]
        corr_vars = ['lambda_max', 'spectral_gap', 'entropy', 'absurdity_gap', 'thz_ratio']
        corr_matrix = df[corr_vars].corr()
        im = ax6.imshow(corr_matrix, cmap='coolwarm', aspect='auto', vmin=-1, vmax=1)
        ax6.set_xticks(range(len(corr_vars)))
        ax6.set_yticks(range(len(corr_vars)))
        ax6.set_xticklabels(corr_vars, rotation=45, ha='right')
        ax6.set_yticklabels(corr_vars)
        ax6.set_title('Correlation Matrix')
        
        # Add correlation values
        for i in range(len(corr_vars)):
            for j in range(len(corr_vars)):
                text = ax6.text(j, i, f'{corr_matrix.iloc[i, j]:.2f}',
                              ha="center", va="center", color="black", fontsize=8)
        
        cbar = plt.colorbar(im, ax=ax6)
        cbar.set_label('Correlation')
        
        plt.suptitle(f'EntPTC Analysis Summary (N={len(df)} recordings)', fontsize=16)
        plt.tight_layout()
        
        filepath = self.subdirs['summary'] / 'summary_statistics.png'
        plt.savefig(filepath, bbox_inches='tight')
        plt.close()
        
        return filepath
    
    def generate_all_visualizations(self, csv_file='entptc_all_subjects_results.csv'):
        """
        Generate all visualizations from results CSV.
        """
        print("=" * 80)
        print("Generating All Visualizations")
        print("=" * 80)
        
        # Load results
        csv_path = self.results_dir / csv_file
        if not csv_path.exists():
            print(f"Error: {csv_path} not found")
            return
        
        df = pd.read_csv(csv_path)
        print(f"\nLoaded {len(df)} results from {csv_file}")
        
        # Generate summary plots
        print("\nGenerating summary visualizations...")
        self.plot_summary_statistics(df)
        print("  ✓ Summary statistics")
        
        self.plot_absurdity_gap_comparison(df)
        print("  ✓ Absurdity Gap comparison")
        
        self.plot_thz_structural_invariants(df)
        print("  ✓ THz structural invariants")
        
        print("\n" + "=" * 80)
        print("Visualization generation complete!")
        print(f"All figures saved to: {self.figures_dir}")
        print("=" * 80)

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description='Generate all EntPTC visualizations')
    parser.add_argument('--results-dir', default='/home/ubuntu/entptc_results',
                        help='Path to results directory')
    parser.add_argument('--csv-file', default='entptc_all_subjects_results.csv',
                        help='Name of results CSV file')
    
    args = parser.parse_args()
    
    generator = VisualizationGenerator(results_dir=args.results_dir)
    generator.generate_all_visualizations(csv_file=args.csv_file)
