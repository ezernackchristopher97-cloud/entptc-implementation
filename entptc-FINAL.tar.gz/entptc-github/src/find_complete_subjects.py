#!/usr/bin/env python3.11
"""
Find Complete Subjects for EntPTC Analysis
==========================================

Identifies subjects with complete EO/EC × pre/post blocks.

Requirements:
- Eyes Open (EO) pre-task
- Eyes Closed (EC) pre-task  
- Eyes Open (EO) post-task
- Eyes Closed (EC) post-task
- Same recording parameters (64 channels, 1000Hz, ~3min)

Author: EntPTC Research Team
Date: December 2024
"""

from pathlib import Path
import pyedflib
import pandas as pd
from collections import defaultdict

def check_edf_parameters(edf_path):
    """
    Check if EDF file meets requirements.
    
    Returns:
        (valid, n_channels, sample_rate, duration)
    """
    try:
        f = pyedflib.EdfReader(str(edf_path))
        n_channels = f.signals_in_file
        sample_rate = f.getSampleFrequency(0)
        duration = f.file_duration
        f.close()
        
        # Check requirements
        # Note: Dataset may have 65 channels (64 + reference), accept both
        valid_channels = n_channels in [64, 65]
        valid_rate = abs(sample_rate - 1000) < 10  # Allow small variation
        valid_duration = 120 < duration < 300  # 2-5 minutes
        
        valid = valid_channels and valid_rate and valid_duration
        
        return valid, n_channels, sample_rate, duration
    except Exception as e:
        return False, 0, 0, 0

def find_complete_subjects(data_dir='/home/ubuntu/ds005385_full'):
    """
    Find all subjects with complete EO/EC × pre/post blocks.
    
    Returns:
        DataFrame with complete subjects and their files
    """
    data_path = Path(data_dir)
    
    # Group files by subject
    subject_files = defaultdict(lambda: {
        'EO_pre': None,
        'EC_pre': None,
        'EO_post': None,
        'EC_post': None
    })
    
    print("Scanning dataset for complete subjects...")
    print("Requirements: EO/EC × pre/post, 64-65 channels, 1000Hz, 2-5min duration")
    print()
    
    # Scan all EDF files
    for subject_dir in sorted(data_path.glob('sub-*')):
        subject_id = subject_dir.name
        
        for session_dir in subject_dir.glob('ses-*'):
            session = session_dir.name
            eeg_dir = session_dir / 'eeg'
            
            if not eeg_dir.exists():
                continue
            
            for edf_file in eeg_dir.glob('*.edf'):
                # Check if file is accessible
                if not edf_file.is_file() or edf_file.stat().st_size == 0:
                    continue
                
                # Parse filename
                parts = edf_file.stem.split('_')
                task = None
                acq = None
                
                for part in parts:
                    if part.startswith('task-'):
                        task = part.replace('task-', '')
                    elif part.startswith('acq-'):
                        acq = part.replace('acq-', '')
                
                # Check parameters
                valid, n_ch, sr, dur = check_edf_parameters(edf_file)
                if not valid:
                    continue
                
                # Determine condition from task and acq
                if task == 'EyesOpen' and acq == 'pre':
                    key = 'EO_pre'
                elif task == 'EyesOpen' and acq == 'post':
                    key = 'EO_post'
                elif task == 'EyesClosed' and acq == 'pre':
                    key = 'EC_pre'
                elif task == 'EyesClosed' and acq == 'post':
                    key = 'EC_post'
                else:
                    continue
                
                # Store file info
                subject_files[subject_id][key] = {
                    'path': str(edf_file),
                    'channels': n_ch,
                    'sample_rate': sr,
                    'duration': dur
                }
    
    # Find complete subjects
    complete_subjects = []
    
    for subject_id, files in subject_files.items():
        # Check if all 4 conditions present
        if all(files[key] is not None for key in ['EO_pre', 'EC_pre', 'EO_post', 'EC_post']):
            # Check parameter consistency
            channels = [files[key]['channels'] for key in ['EO_pre', 'EC_pre', 'EO_post', 'EC_post']]
            rates = [files[key]['sample_rate'] for key in ['EO_pre', 'EC_pre', 'EO_post', 'EC_post']]
            
            # All should match
            if len(set(channels)) == 1 and len(set(rates)) == 1:
                complete_subjects.append({
                    'subject_id': subject_id,
                    'n_channels': channels[0],
                    'sample_rate': rates[0],
                    'EO_pre_path': files['EO_pre']['path'],
                    'EC_pre_path': files['EC_pre']['path'],
                    'EO_post_path': files['EO_post']['path'],
                    'EC_post_path': files['EC_post']['path'],
                    'EO_pre_duration': files['EO_pre']['duration'],
                    'EC_pre_duration': files['EC_pre']['duration'],
                    'EO_post_duration': files['EO_post']['duration'],
                    'EC_post_duration': files['EC_post']['duration']
                })
    
    df = pd.DataFrame(complete_subjects)
    
    return df

def main():
    print("=" * 80)
    print("EntPTC Complete Subject Finder")
    print("=" * 80)
    print()
    
    # Find complete subjects
    df = find_complete_subjects()
    
    print(f"\n{'=' * 80}")
    print(f"RESULTS")
    print(f"{'=' * 80}\n")
    
    print(f"Complete subjects found: {len(df)}")
    print(f"Total EDF files: {len(df) * 4}")
    print()
    
    if len(df) > 0:
        print("Channel distribution:")
        print(df['n_channels'].value_counts())
        print()
        
        print("Sample rate distribution:")
        print(df['sample_rate'].value_counts())
        print()
        
        print(f"First 10 complete subjects:")
        print(df[['subject_id', 'n_channels', 'sample_rate']].head(10))
        print()
        
        # Save to CSV
        output_path = '/home/ubuntu/entptc_results/complete_subjects.csv'
        df.to_csv(output_path, index=False)
        print(f"Complete subject list saved to: {output_path}")
        
        # Assessment
        print(f"\n{'=' * 80}")
        print("SCIENTIFIC ASSESSMENT")
        print(f"{'=' * 80}\n")
        
        if len(df) >= 50:
            print("✅ EXCELLENT: ≥50 complete subjects")
            print("   Strong methods + preliminary results paper")
        elif len(df) >= 30:
            print("✅ VERY SOLID: 30-49 complete subjects")
            print("   Strong methods validation paper")
        elif len(df) >= 20:
            print("✅ ACCEPTABLE: 20-29 complete subjects")
            print("   Proof-of-concept / methods paper")
        else:
            print("⚠️  LIMITED: <20 complete subjects")
            print("   May be insufficient for publication")
    else:
        print("❌ No complete subjects found!")
        print("   Check dataset download and file structure")
    
    print()

if __name__ == "__main__":
    main()
