#!/usr/bin/env python3.11
"""
EntPTC Full Dataset Analysis - PyTorch Implementation
======================================================

Process all 1260 EDF files through the complete EntPTC PyTorch simulation.

Author: EntPTC Research Team
Date: December 2024
"""

import sys
sys.path.append('/home/ubuntu')

from entptc_pytorch_simulation import EntPTCPipeline
import pandas as pd
import numpy as np
from pathlib import Path
from tqdm import tqdm
import torch

def find_all_edf_files(data_dir='/home/ubuntu/ds005385_full'):
    """
    Find all accessible EDF files in the dataset.
    
    Returns:
        List of tuples: (subject_id, session, task, acq, edf_path)
    """
    data_path = Path(data_dir)
    edf_files = []
    
    for subject_dir in sorted(data_path.glob('sub-*')):
        subject_id = subject_dir.name
        
        for session_dir in subject_dir.glob('ses-*'):
            session = session_dir.name
            eeg_dir = session_dir / 'eeg'
            
            if not eeg_dir.exists():
                continue
            
            for edf_file in eeg_dir.glob('*.edf'):
                # Check if file is actually accessible (not just symlink)
                if not edf_file.is_file() or edf_file.stat().st_size == 0:
                    continue
                
                # Parse filename
                parts = edf_file.stem.split('_')
                task = None
                acq = None
                
                for part in parts:
                    if part.startswith('task-'):
                        task = part.replace('task-', '')
                    elif part.startswith('acq-'):
                        acq = part.replace('acq-', '')
                
                if task and acq:
                    edf_files.append((subject_id, session, task, acq, str(edf_file)))
    
    return edf_files

def main():
    print("=" * 80)
    print("EntPTC Full Dataset Analysis - PyTorch Implementation")
    print("=" * 80)
    
    # Initialize pipeline
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    pipeline = EntPTCPipeline(device=device)
    
    print(f"\nDevice: {device}")
    print("Finding all accessible EDF files...")
    
    # Find all EDF files
    edf_files = find_all_edf_files()
    
    print(f"Found {len(edf_files)} accessible EDF files")
    print("\nProcessing all files through EntPTC pipeline...")
    print("This implements:")
    print("  - Quaternionic filtering (Stage 1)")
    print("  - Real projection (Stage 2)")
    print("  - Perron-Frobenius collapse (Stage 3)")
    print("  - Entropy field on T³")
    print("  - Geodesic computation")
    print("  - Absurdity Gap (POST-OPERATOR)")
    print("  - THz inference (structural invariants, NO conversion)")
    print()
    
    # Process all files
    results_list = []
    failed_files = []
    
    for subject_id, session, task, acq, edf_path in tqdm(edf_files, desc="Processing"):
        try:
            result = pipeline.process_edf_file(edf_path)
            
            if result is not None:
                result['subject_id'] = subject_id
                result['session'] = session
                result['task'] = task
                result['acq'] = acq
                results_list.append(result)
        except Exception as e:
            failed_files.append((subject_id, session, task, acq, str(e)))
            print(f"\nError: {subject_id} {session} {task} {acq}: {e}")
    
    print(f"\n\nProcessing complete!")
    print(f"  Successful: {len(results_list)}")
    print(f"  Failed: {len(failed_files)}")
    
    # Save results
    if results_list:
        print("\nSaving results to CSV...")
        df = pd.DataFrame(results_list)
        
        # Reorder columns
        cols = ['subject_id', 'session', 'task', 'acq', 'lambda_max', 'lambda_2',
                'spectral_gap', 'entropy', 'absurdity_gap', 'thz_ratio',
                'thz_normalized_gap', 'thz_decay_exponent', 'thz_inferred', 'thz_confidence']
        df = df[cols]
        
        output_path = Path('/home/ubuntu/entptc_results/entptc_pytorch_full_results.csv')
        df.to_csv(output_path, index=False)
        print(f"Results saved to: {output_path}")
        
        # Generate summary statistics
        print("\nGenerating summary statistics...")
        summary = generate_summary_statistics(df)
        summary_path = Path('/home/ubuntu/entptc_results/entptc_pytorch_summary.csv')
        summary.to_csv(summary_path)
        print(f"Summary saved to: {summary_path}")
        
        # Print key findings
        print("\n" + "=" * 80)
        print("KEY FINDINGS")
        print("=" * 80)
        print(f"\nOverall Statistics (N={len(df)}):")
        print(f"  λ_max:         {df['lambda_max'].mean():.4f} ± {df['lambda_max'].std():.4f}")
        print(f"  Spectral gap:  {df['spectral_gap'].mean():.4f} ± {df['spectral_gap'].std():.4f}")
        print(f"  Entropy:       {df['entropy'].mean():.4f} ± {df['entropy'].std():.4f}")
        print(f"  Absurdity Gap: {df['absurdity_gap'].mean():.4f} ± {df['absurdity_gap'].std():.4f}")
        print(f"  THz inferred:  {df['thz_inferred'].sum()}/{len(df)} ({100*df['thz_inferred'].mean():.1f}%)")
        
        print("\nBy Task:")
        for task in df['task'].unique():
            task_df = df[df['task'] == task]
            print(f"\n  {task} (N={len(task_df)}):")
            print(f"    Spectral gap:  {task_df['spectral_gap'].mean():.4f} ± {task_df['spectral_gap'].std():.4f}")
            print(f"    Absurdity Gap: {task_df['absurdity_gap'].mean():.4f} ± {task_df['absurdity_gap'].std():.4f}")
    
    # Save failed files log
    if failed_files:
        failed_df = pd.DataFrame(failed_files, 
                                columns=['subject_id', 'session', 'task', 'acq', 'error'])
        failed_path = Path('/home/ubuntu/entptc_results/failed_files_pytorch.csv')
        failed_df.to_csv(failed_path, index=False)
        print(f"\nFailed files log saved to: {failed_path}")
    
    print("\n" + "=" * 80)
    print("Analysis complete!")
    print("=" * 80)

def generate_summary_statistics(df):
    """Generate summary statistics by condition."""
    summary_stats = []
    
    # Overall
    summary_stats.append({
        'condition': 'All',
        'n': len(df),
        'lambda_max_mean': df['lambda_max'].mean(),
        'lambda_max_std': df['lambda_max'].std(),
        'spectral_gap_mean': df['spectral_gap'].mean(),
        'spectral_gap_std': df['spectral_gap'].std(),
        'entropy_mean': df['entropy'].mean(),
        'entropy_std': df['entropy'].std(),
        'absurdity_gap_mean': df['absurdity_gap'].mean(),
        'absurdity_gap_std': df['absurdity_gap'].std(),
        'thz_inferred_pct': 100 * df['thz_inferred'].mean()
    })
    
    # By task
    for task in df['task'].unique():
        task_df = df[df['task'] == task]
        summary_stats.append({
            'condition': f'Task: {task}',
            'n': len(task_df),
            'lambda_max_mean': task_df['lambda_max'].mean(),
            'lambda_max_std': task_df['lambda_max'].std(),
            'spectral_gap_mean': task_df['spectral_gap'].mean(),
            'spectral_gap_std': task_df['spectral_gap'].std(),
            'entropy_mean': task_df['entropy'].mean(),
            'entropy_std': task_df['entropy'].std(),
            'absurdity_gap_mean': task_df['absurdity_gap'].mean(),
            'absurdity_gap_std': task_df['absurdity_gap'].std(),
            'thz_inferred_pct': 100 * task_df['thz_inferred'].mean()
        })
    
    # By acquisition
    for acq in df['acq'].unique():
        acq_df = df[df['acq'] == acq]
        summary_stats.append({
            'condition': f'Acquisition: {acq}',
            'n': len(acq_df),
            'lambda_max_mean': acq_df['lambda_max'].mean(),
            'lambda_max_std': acq_df['lambda_max'].std(),
            'spectral_gap_mean': acq_df['spectral_gap'].mean(),
            'spectral_gap_std': acq_df['spectral_gap'].std(),
            'entropy_mean': acq_df['entropy'].mean(),
            'entropy_std': acq_df['entropy'].std(),
            'absurdity_gap_mean': acq_df['absurdity_gap'].mean(),
            'absurdity_gap_std': acq_df['absurdity_gap'].std(),
            'thz_inferred_pct': 100 * acq_df['thz_inferred'].mean()
        })
    
    return pd.DataFrame(summary_stats)

if __name__ == "__main__":
    main()
